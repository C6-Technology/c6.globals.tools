﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Xml.Linq;
using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;
using System.IO;
using System.Collections;

using System.Diagnostics;

/// <summary>
/// LittleHelpers is a class containing diverse "tools" and other "hacks" to make the developers life easier
/// </summary>

namespace SocialCom.Globals.Tools
{
    public class LittleHelpers
    {
        #region Global Variables
		#region Variable definition

        private string csvSeparator = Properties.Settings.Default.defaultCSVSeparator;

        #endregion

        #region Properties

        /// <summary>
        /// The Separator used as default if no Separator is used for all CSV related functions in this class!
        /// </summary>
        public string CSVSeparator
        {
            get
            {
                return csvSeparator;
            }
            set
            {
                csvSeparator = value.ToString();
            }
        }

        #endregion
        #endregion

        #region (De-)Constructur
        public LittleHelpers()
        {
        }
        #endregion

        #region SQL related
        public string GetEscapedSQLValue(string EscapeMe)
        {
            string returnValue = EscapeMe.Replace("'", "''").Replace("’", "’’").Replace("‘", "‘‘");

            return returnValue;
        }
        #endregion

        #region DebugPrinting
        public void DebugPrint(bool condition, string Message)
        {
#if DEBUG
            Debug.WriteLineIf(condition, CreateDebugMessageString(Message));
#endif
        }
        
        public string CreateDebugMessageString(string Message)
        {
            return DateTime.Now.ToString() + " || " + Message;
        }
        #endregion

        #region Log
        public delegate void AddLogMessageDelegate(bool condition, string message);
        public AddLogMessageDelegate AddLogMessageValue;

        private void AddLogMessage(bool condition, string message)
        {
            if (AddLogMessageValue != null)
                AddLogMessageValue(condition, message);
            else
                DebugPrint(condition, message);
        }
        #endregion

        #region Array related methods
        #region Method StringArray2String
        /// <summary>
		/// A simple function to "flaten" a string array into a single string. The function simply add's each field and delimites it by using ||.
		/// </summary>
		/// <param name="Array2Convert">A one dimensional string array.</param>
		/// <returns>A string with delimiter of || for each array field.</returns>
		public string StringArray2String(string[] Array2Convert)
		{
			if (Array2Convert.Rank > 1)
				throw new Exception("StringArray2String only handles one dimensional arrays");
			else
			{
				string returnValue = "";    // initializing returnValue            

				foreach (string str in Array2Convert)
					returnValue += str + "||";

				return returnValue.Substring(0, returnValue.Length - 2);    // return everything but the last two ||
			}
		}
		#endregion
        #endregion

		#region CSV- Handling
		#region Seperated HeaderColumnHandler
		/// <summary>
		/// HeaderColumnHandler delivers a string[] or DataTable (with setup columns) depending on Headline. 
		/// Delivers a null if an error occured (usually this is a doubled column within the Headline.
		/// 
		/// Note1:  DataTable.Clear() & DataTable.Columns.Clear() is executed, so an created but empty table is
		///         enough for the reference table :)
		///         
		/// Note2:  In the case that a Column is repeadeately existing within a Headline, 
		///         we consequently add a numbering, starting with 1 for the first doublette
		///         to the name of the Column.
		/// </summary>
		/// <typeparam name="ReturnValueType">Either a DataTable or string[], anything else would result in an Exception!</typeparam>
		/// <param name="Path">The path to the CSV- or XML- file from which the header should be retrieved!</param>
		/// <param name="Headline">A string containing the header line.</param>
		/// <param name="Seperator">A string array containing the seperator data</param>
		/// <param name="Encode">The encoding of the file!</param>
		/// <returns>
		///        Depending on ReturnValueType returns a DataTable or a string array contained in an object.
		///        NULL if an error occours, usually this error means that a doubled header was contained in the Headline!
		/// </returns>        

		public void GetCSVColumns<ReturnValueType>(string Path, string Headline, string[] Seperator, Encoding Encode, ref object ReturnValue)
		{
			// TODO: error handling has to be implemented !!
			// TODO: Handling XML- Files has to be implemented!!
			if (Path.ToLower().EndsWith(".xml"))
				throw new Exception("XML Handling not yet implemented!");

			//MessageBox.Show("Checking whether the file exists!");
			if (File.Exists(Path))
			{
				//MessageBox.Show("Opening CSV: " + Path);
				using (StreamReader sr = new StreamReader(Path, Encode))
				{
					string headLine = sr.ReadLine().TrimStart('\"').TrimEnd('\"');  // we have to remove the first and last " since it doesn't belong to the lines and was added just as start- and end- delimiter
					sr.Close();    // we do not need the file anymore :)                    

					if (typeof(ReturnValueType) == typeof(string[]))
					{
						string[] retValue = new string[1000];
						GetCSVColumns(headLine, Seperator, ref retValue);

						ReturnValue = retValue;
					}

					if (typeof(ReturnValueType) == typeof(DataTable))
					{
						DataTable retValue = new DataTable();
						GetCSVColumns(headLine, Seperator, ref retValue);

						ReturnValue = retValue;
					}

					if (typeof(ReturnValueType) == typeof(Hashtable))
					{
						Hashtable retValue = new Hashtable();
						GetCSVColumns(headLine, Seperator, ref retValue);

						ReturnValue = retValue;
					}
				}
			}
			else
			{
				//MessageBox.Show("File {0} doesn't exist!", Path);
				throw new IOException(string.Format("File {0} doesn't exist!", Path));
			}
		}

		/// <summary>
		/// This function delivers the separated columns as an DataTable.
		/// 
		/// Note1:  DataTable.Clear() & DataTable.Columns.Clear() is executed, so an created but empty table is
		///         enough for the reference table :)
		///         
		/// Note2:  In the case that a Column is repeadeately existing within a Headline, 
		///         we consequently add a numbering, starting with 1 for the first doublette
		///         to the name of the Column.
		/// </summary>
		/// <param name="Headline">The string with the headline itself.</param>
		/// <param name="Seperator">A string array with all separating parameters</param>
		/// <param name="ReturnValue">Returns the headline within an Hashtable</param>
		public void GetCSVColumns(string Headline, string[] Seperator, ref DataTable ReturnValue)
		{
			ReturnValue.Clear();            // clearing all data out of the referenced ReturnValue
			ReturnValue.Columns.Clear();    // clears all existing columns out of the referenced ReturnValue

			Hashtable zw = new Hashtable();
			GetCSVColumns(Headline, Seperator, ref zw);

			foreach (string KeyName in zw.Keys)
				ReturnValue.Columns.Add(new DataColumn(zw[KeyName].ToString()));

			// and done :)
		}
		/// <summary>
		/// This function delivers the separated columns as an string[] array
		/// 
		/// Note:   In the case that a Column is repeadeately existing within a Headline, 
		///         we consequently add a numbering, starting with 1 for the first doublette
		///         to the name of the Column.
		/// </summary>
		/// <param name="Headline">The string with the headline itself.</param>
		/// <param name="Seperator">A string array with all separating parameters</param>
		/// <param name="ReturnValue">Returns the headline within an Hashtable</param>
		public void GetCSVColumns(string Headline, string[] Seperator, ref string[] ReturnValue)
		{
			Hashtable zw = new Hashtable();
			GetCSVColumns(Headline, Seperator, ref zw);

			string[] retValue = new string[zw.Count];

			int x = 0;
			foreach (string KeyName in zw.Keys)
			{
				retValue[x] = zw[KeyName].ToString();
				x++;
			}

			if (retValue.Length > ReturnValue.Length)
				throw new Exception("Developer Error: GetCSVColumns - string[] ReturnValue is undersized! A size of " + retValue.Length.ToString());

			ReturnValue = retValue;
		}
		/// <summary>
		/// This function delivers the separated columns as an Hastable
		/// </summary>
		/// <param name="Headline">The string with the headline itself.</param>
		/// <param name="Seperator">A string array with all separating parameters</param>
		/// <param name="ReturnValue">Returns the headline within an Hashtable</param>
		public void GetCSVColumns(string Headline, string[] Seperator, ref Hashtable ReturnValue)
		{
			if (Headline.Length == 0)
				throw new Exception("Developer Error: Headline MUST NOT be empty!");

			if (Seperator.Length == 0)
				throw new Exception("Developer Error: Separator MUST NOT be empty!");

			string[] HeaderColumns = Headline.Split(Seperator, StringSplitOptions.RemoveEmptyEntries);

			Hashtable HeadlineColumns = new Hashtable();
			/*
			 * Note:    In the case that a Column is repeadeately existing within a Headline, 
			 *          we consequently add a numbering, starting with 1 for the first doublette
			 *          to the name of the Column.
			 */
			try
			{
				foreach (string header in HeaderColumns)
				{
					string Header2Add = header;

					if (HeadlineColumns.ContainsKey(Header2Add))    // If the header exists, we do add a number to it :)
					{
						int orgHeaderCounter = 1;                   // instead of handling the number for each header
						// we do simpy run through a while-loop and increase
						// the counter as much as needed :)

						while (HeadlineColumns.ContainsKey(header))
						{
							if (HeadlineColumns.ContainsKey(header + orgHeaderCounter.ToString()))
								orgHeaderCounter++;
							else
							{
								Header2Add += orgHeaderCounter.ToString();
								break;
							}
						}
					}
					HeadlineColumns.Add(Header2Add, Header2Add);
				}
			}
			catch (Exception e)                // since we expect only one issue, we'll just make the table null and raise NO warning
			// TODO: Somehow an error should be raised to give the calling routine the chance to handle it.
			{
				//MessageBox.Show(e.ToString());
				ReturnValue = null; // ensures that the default value for the valuetype is delivered back in case of an error :)
			}

			//MessageBox.Show("HeadlineColumns.Values.Count = " + HeadlineColumns.Values.Count);
			ReturnValue = HeadlineColumns;
		}
		#endregion

		#region CSV2DataTable
		/// <summary>
		/// This method creates a DataTable from a CSV.
		/// 
		/// If within the CSV headers are existing and if one column is doubled, this method returns an empty DataTable and raises NO error.
		/// 
		/// This method assumes that Headlines, if any, aren't ignored per default!
		/// </summary>
		/// <param name="Path">The full path to the CSV.</param>
		/// <param name="Separator">A string array containing the separator(s).</param>
		/// <param name="Encode">The encoding of the file!</param>
		/// <param name="HasHeadline">true ~ has headlines; false ~ hos none</param>
		/// <param name="TableName">If wished, the data table object gets a table name :)</param>
		/// <returns>A DataTable object, representing the data from the CSV. 
		/// </returns>
		public DataTable CSV2DataTable(string Path, string[] Separator, Encoding Encode, bool HasHeadline, string TableName)
		{
			return CSV2DataTable(Path, Separator, Encode, HasHeadline, TableName, false);
		}
		/// <summary>
		/// This method creates a DataTable from a CSV.
		/// 
		/// If within the CSV headers are existing and if one column is doubled, this method returns an empty DataTable and raises NO error.
		/// 
		/// This method assumes that Headlines, if any, aren't ignored per default!
		/// </summary>
		/// <param name="Path">The full path to the CSV.</param>
		/// <param name="Separator">A string array containing the separator(s).</param>
		/// <param name="Encode">The encoding of the file!</param>
		/// <param name="HasHeadline">true ~ has headlines; false ~ hos none</param>
		/// <param name="TableName">If wished, the data table object gets a table name :)</param>
		/// <param name="ignoreHeadline">if true, the FIRST line of each file is ALWAYS ignored. If false && HasHeadline == true, the first line is interpreted as headline.</param>
		/// <returns>A DataTable object, representing the data from the CSV. 
		/// </returns>
		public DataTable CSV2DataTable(string Path, string[] Separator, Encoding Encode, bool HasHeadline, string TableName, bool ignoreHeadline)
		{			
			// initializing some worker varialbes.
			DataTable retValue = new DataTable();
			bool stop = false;

			bool isChildLine = false;						// this is used if the importer determined that a line is belonging to the line before (f.e. if CR(&/|)LF is not correctly escaperd);
			string[] csvColumns = new string[0];			// initialize the csvColumns placeholder
			string currentColumn = "";						// initialize the current column string	
			int csvColumnCounter = 0;						// initializing the column counter		
			string fullSeperator = "";						// initialize the full seperator

			for (int x = 0; x <= Separator.GetUpperBound(0); x++)		// get one seperator string
				fullSeperator += Separator[x];								

			if (TableName != "")        // well, we set the table name only if we got one :)
				retValue.TableName = TableName;

			//MessageBox.Show("Reading data into table: " + TableName);

			// TODO: error handling has to be implemented !!
			//MessageBox.Show("Checking whether the file exists!");
			if (File.Exists(Path))
			{
				//MessageBox.Show("Opening CSV: " + Path);

				using (StreamReader sr = new StreamReader(Path, Encode))
				{
					if ((HasHeadline) && (!ignoreHeadline))        // if so we create the column headers in our table :)
					{
						string headLine = sr.ReadLine().TrimStart('\"').TrimEnd('\"');  // we have to remove the first and last " since it doesn't belong to the lines and was added just as start- and end- delimiter
						GetCSVColumns(headLine, Separator, ref retValue);
					}

					// well, now let's do the real, importing work

					while ((sr.Peek() > -1) && (stop == false))        // if stop == true (which is the case if a double header was found, we do not go on here
					{

						// string csvRow = sr.ReadLine().TrimStart('\"').TrimEnd('\"');  // we have to remove the first and last " since it doesn't belong to the lines and was added just as start- and end- delimiter;
						// string[] csvColumns = csvRow.Split(Separator, StringSplitOptions.None); // it may occour that we have empty columns - we can not delete them and have to empty insert them !

						string csvRow = sr.ReadLine();		// we read it line by line
						
#if DEBUG
						Debug.Print(csvRow);
#endif

						if (!isChildLine)					// the following is done ONLY if we are not working on a child line
							csvColumns = new string[0];		// initializng the base string containing the data

						/*
							Figuring out whether we can simply split, use the RegExpression or need to go throught the hard way
						*/
						if (!csvRow.Contains("\""))
						{
							csvColumns = csvRow.Split(Separator, StringSplitOptions.None); // it may occour that we have empty columns - we can not delete them and have to empty insert them !
						}
						else
						{
							/*
							 * create the regular expression and compile it
							 */
							Regex getColumnsRegEx = new Regex("(\"*?\"|[^,]+|'.*?')", RegexOptions.Compiled | RegexOptions.ExplicitCapture);							
							// now get all matches
							MatchCollection mc = getColumnsRegEx.Matches(csvRow);

							/*
							 * Check whether the result of the regular expression is corresponding to the number of columns we do have to handle							
							 * Don't check if we handle a child line.
							 */
							if ((mc.Count == retValue.Columns.Count) && (!isChildLine))	// TODO: Check how to handle this if no Headercolumn exist!
							{
								// initialize the string array
								csvColumns = new string[mc.Count];
								int x = 0;

								// and fill it
								foreach (Match m in mc)
								{
									csvColumns[x] = m.Value.ToString();
									x++;
								}

#if DEBUG
								Debug.Print("\r\n\r\nReg-Expression result: {0} columns", csvColumns.GetUpperBound(0));
#endif
							}
							else
							{
								/*
								 * Obviousely not, therefore we have to handle all cases step by step - this is the slowest process
								 *
								 * Now handling the following cases:
								 * 
								 * 1)	__,__
								 * 2)	"__","__"				
								 * 3)	"__",__
								 * 4)	__,"__"
								 * 5)	"_""_""_"				"" escaped within a "__"
								 * 6)	""")					"" escaped with left or right side
								 * 6.1)	"("")					(left side "" escaped)
								 * 6.2)	("")"					(right side "" escaped)
								 * 7)	"_"",""_"				escaped "" with comma included
								 * 7.1)	"__""__,__""__"
								 * 
								 */

								bool ignoreSeperator = false;		// true if the seperator should be ignored, false if not.

								if (!isChildLine)
								{
									currentColumn = "";				// only clear the current column if we are not working on a child line
									csvColumns = new string[0];		// initialize the array only if we are not working on a child line
									csvColumnCounter = 0;			// initialize the column counter only if we are not working on a child line
								}

								// TODO: for now, ONLY seperators with 1 char are handled!
								for (int x = 0; x < csvRow.Length; x++)
								{
									string currentChar = csvRow[x].ToString();
									CSVSeperatorHandler(ref x, ref csvRow, ref currentChar, fullSeperator, ref ignoreSeperator, ref csvColumnCounter, ref csvColumns, ref currentColumn, retValue.Columns.Count);

									// check whether we have a "
									if (currentChar == "\"")
									{
										if ((x + 1) >= csvRow.Length)			// is the next char end of line?
										{
											ignoreSeperator = false;		// reset the ignoreSeperator to false
											break;							// and break
										}
										else								// nope, we can go on, let's see what comes next
										{
											//if (ignoreSeperator == false)	// well, the 'first' " we found, therefore we ignore the seperator from now on
											//{
											//ignoreSeperator = true;

											if (csvRow[x + 1].ToString() == "\"")				// is the following char a " too?
											{
												if ((x + 2) <= csvRow.Length)					// yes? and is there another char behind it?
												{
													if (csvRow[x + 2].ToString() == "\"")		// and is the overnext a " as well?
													{
														// we've identified a """ :)
														ignoreSeperator = ignoreSeperator == true ? false : true;	// well, than let's alternate the ignoreSeperator - this handles the left/right thematic automatically 8-)
														currentColumn += "\"";										// and add a " to the current column

														x = x + 2;													// and go on with the third char :)
													}
													else										// well, we found a double "" which means ...
													{
														if (ignoreSeperator)					// ... we found an " escape sequence ("") within a string column
														{
															currentColumn += "\"";
															/*
															 * Speed optimization. We are going to copy all chars up until the next "
															 */
															x++;
															currentColumn += csvRow.IndexOf('\"', x + 1) - x - 1 > 0 ? csvRow.Substring(x + 1, csvRow.IndexOf('\"', x + 1) - x - 1) : "";
															//x = x + csvRow.Substring(x + 1, csvRow.IndexOf('\"', x + 1) - x - 1).Length;
															x = x + (csvRow.IndexOf('\"', x + 1) - x - 1 > 0 ? csvRow.Substring(x + 1, csvRow.IndexOf('\"', x + 1) - x - 1).Length : 0);
														}
														else
															x++;								// ... we found an empty column and therefore can go directly to the next char
													}
												}
												else
												{
													ignoreSeperator = false;
#if DEBUG
													Debug.Print("LittleHelper.CSV2DataTable: ERROR in CSV, line ends with \"\"");
#endif
													throw new Exception("LittleHelper.CSV2DataTable: ERROR in CSV, line ends with \"\"");
												}
											}
											else
											{
												ignoreSeperator = ignoreSeperator == true ? false : true;	// well, than let's alternate the ignoreSeperator												
												/*
												 * Speed optimization. We are going to copy all chars up until the next "
												 * 
												 * If ignoreSeperator is true AND there is another char following x
												 */
												if ((ignoreSeperator) && (((x + 1) <= csvRow.Length)))
												{
													currentColumn += csvRow.IndexOf('\"', x + 1) - x - 1 > 0 ? csvRow.Substring(x + 1, csvRow.IndexOf('\"', x + 1) - x - 1) : "";
													//x = x + csvRow.Substring(x + 1, csvRow.IndexOf('\"', x + 1) - x - 1).Length;
													x = x + (csvRow.IndexOf('\"', x + 1) - x - 1 > 0 ? csvRow.Substring(x + 1, csvRow.IndexOf('\"', x + 1) - x - 1).Length : 0);
												}
											}
										}
									}
									else									
									{
										// TODO: if this doesn't result in an useful result, simply consider to take the substring to the end of line and check for the seperator. 

										/* 
										 * we might shortcut here - so first we copy now everything from this point to the next seperator
										 * if we can't shortcut simply since there are not enough chars or no , ... we simply return an empty ZW :)
										 */
										string zw = csvRow.IndexOf(fullSeperator, x + 1) - x - 1 > 0 ? csvRow.Substring(x + 1, csvRow.IndexOf(fullSeperator, x + 1) - x - 1) : "";										
										/*
										 * now, if there is a " in zw, we need to use the current char (or TODO: optimize here again by copying to the next " ;))
										 */
										if (zw.IndexOf("\"") != -1)
											if (zw.IndexOf("\"") != zw.Length - 1)	// check whether it the index is equal the last char in the string
												currentColumn += currentChar;		// nope - well than we have to go through it char by char
											else									// yes, if so, we copy everything except the last char
											{
												currentColumn += currentChar + zw.Substring(0, zw.Length - 2);
												x = x + zw.Length;
											}

										else									// since there is no " in zw, we can simply copy the whole string 8-)
										{
											currentColumn += currentChar + zw;
											x = x + zw.Length;											
										}
									}
								}

								/*
								 * If the current number of columns is below the number of columns
								 * we originally determined, obviosely, the next line belongs to 
								 * this one.
								 * 
								 * Rule:	We only expect a following line as ChildLine if before an " has been openend
								 *			and triggered ignoreSeperator to true!
								 */
								if ((csvColumnCounter < retValue.Columns.Count) && (ignoreSeperator))	
								{
									isChildLine = true;
									currentColumn += "\r\n";					// add a carriage return, new line to the column
								}
								else
								{
									isChildLine = false;

									if (currentColumn != "")	// do we need to write the last column?
										// add a new column and store the current value in the current column
										CSVAddCSVColumnColumn(ref csvColumnCounter, retValue.Columns.Count, ref csvColumns, ref currentColumn);
								}
							}
						}

						//MessageBox.Show(csvRow);

						// well, let's do some un-escaping
						if (!isChildLine)
						{
							for (int x = 0; x < csvColumns.GetUpperBound(0); x++)
							{
								csvColumns[x] = csvColumns[x].Replace("\"\"", "\"");
								csvColumns[x] = csvColumns[x].Replace("\\r", "\r");
								csvColumns[x] = csvColumns[x].Replace("\\n", "\n");
							}

							if (retValue.Columns.Count == 0)						// in the case we do not have a header row, we need to create the columns 
								// once after we parsed the first line ...													
								for (int x = 0; x <= csvColumns.GetUpperBound(0); x++)
									retValue.Columns.Add(new DataColumn());

							retValue.Rows.Add(csvColumns);
						}
					}
				}
			}
			else
			{
				//MessageBox.Show("File {0} doesn't exist!", Path);
				throw new IOException(string.Format("File {0} doesn't exist!", Path));
			}

			//MessageBox.Show("CSV2Table... done");
			return retValue;
		}
		#region CSV2DataTable Helper
		#region Seperator Handler
		/// <summary>
		/// 
		/// </summary>
		/// <param name="x"></param>
		/// <param name="csvRow"></param>
		/// <param name="currentChar"></param>
		/// <param name="fullSeperator"></param>
		/// <param name="ignoreSeperator"></param>
		/// <param name="csvColumnCounter"></param>
		/// <param name="csvColumns"></param>
		/// <param name="currentColumn"></param>
		private void CSVSeperatorHandler(ref int x, ref string csvRow, ref string currentChar, string fullSeperator, ref bool ignoreSeperator, ref int csvColumnCounter, ref string[] csvColumns, ref string currentColumn, int retValueColumnsCounter)
		{
			// check whether a Seperator is the current char - except if we do not need to check anyways :)
			if ((currentChar == fullSeperator) && (ignoreSeperator == false))
			{
				// first add a new column and store the current value in the current column
				CSVAddCSVColumnColumn(ref csvColumnCounter, retValueColumnsCounter, ref csvColumns, ref currentColumn);

				// since we are already here, we can go on, so simply x++ :)
				if ((x + 1) >= csvRow.Length)
				{
					ignoreSeperator = false;	// reset the ignoreSeperator to false					
				}
				else
				{
#if DEBUG
					/*
					 * DEBUGGING ONLY	- use this if you want to break @ a specific column or row :)
					 */
					if (currentColumn == "44000-2-1")
						Debug.Print("BREAKPOINT HERE :)");
#endif
		
					// course we can empty the current column
					currentColumn = "";

					currentChar = csvRow[++x].ToString();		// and now we are going to take care about the next char :)
//					if (csvRow[x].ToString() == fullSeperator)	// to ensure that we do catch all possible empty columns we use kind of a recursion here :)
					CSVSeperatorHandler(ref x, ref csvRow, ref currentChar, fullSeperator, ref ignoreSeperator, ref csvColumnCounter, ref csvColumns, ref currentColumn, retValueColumnsCounter);						
				}
			}
		}
		#endregion

		#region Add a CSVColumn column
		/// <summary>
		/// 
		/// </summary>
		/// <param name="csvColumnCounter"></param>
		/// <param name="retValueColumnsCounter"></param>
		/// <param name="csvColumns"></param>
		/// <param name="currentColumn"></param>
		private void CSVAddCSVColumnColumn(ref int csvColumnCounter, int retValueColumnsCounter, ref string[] csvColumns, ref string currentColumn)
		{
			// we only need to expand the csvColumns
			csvColumnCounter++;

			/*
			 * Error checking and throwing
			 * it might appear that the CSV or the developer made an error which has to be analyzed before the system can go on!
			*/
			if ((csvColumnCounter > retValueColumnsCounter) && (retValueColumnsCounter != 0)) // if retValueColumnsCounter == 0, usually no headline has been given, therefore we need to believe that any column imported is a 'good' column.
																							  // After the first row is added, the value is automatically consisting a number of given columns. Consequently more than the first row columns result in an error!
				throw new Exception("LittleHelper.CSV2DataTable.CSVSeperatorHandler: created more columns than the CSV(-Header) allows. Developer or CSV error!");

			// well, let's go on!
			if (csvColumnCounter > csvColumns.GetUpperBound(0))
				Array.Resize(ref csvColumns, csvColumnCounter);		// TODO: Rethink whether there is a faster way to handle this - maybe it is enough to set the array to the size we expect?

			// well, let's store the current column
			csvColumns[csvColumnCounter - 1] = currentColumn;
		}
		#endregion
		#endregion

		#endregion

		#region DataTable2CSV
		public void DataTable2CSV(string Path, DataTable DataTable4CSV, string Separator, Encoding Encode)
		{
			// check Path
			if (Path.EndsWith("\\"))
				throw new Exception("Error: Obviousely a path to an directory instead of a file path was given!");

			using (StreamWriter sw = new StreamWriter(Path, false, Encode))
			{
				// for all the output, "," is the default column delimiter
				string columnDelimiter = "\",\"";

				if (Separator != "")                // well, if we need something else, here we go :)
					columnDelimiter = Separator;

				// tell us what you do
				//MessageBox.Show("DataTable2CSV: Tablename: " + DataTable4CSV.TableName);
				//MessageBox.Show("");

				string outPut = "";    // helper variable

				// then, deploy the column headers first
				if ((Separator == "") || (Separator == "\",\""))
					outPut += "\"";    // start the line with a "

				for (int x = 0; x < DataTable4CSV.Columns.Count; x++)
				{
					outPut += DataTable4CSV.Columns[x].Caption.ToString() + columnDelimiter;
				}

				if ((Separator == "") || (Separator == "\",\""))
					outPut = outPut.Substring(0, outPut.Length - 2);                        // remove the last ," to have a correct line end;
				else
					outPut = outPut.Substring(0, outPut.Length - columnDelimiter.Length);    // remove the entire last content delimiter to have a correct line end;

				sw.WriteLine(outPut);
				//MessageBox.Show(outPut);

				// followed by the content :)    
				for (int x = 0; x < DataTable4CSV.Rows.Count; x++)
				{
					outPut = "";
					if ((Separator == "") || (Separator == "\",\""))
						outPut += "\"";    // start the line with a "

					DataRow dr = DataTable4CSV.Rows[x];
					for (int q = 0; q <= dr.ItemArray.GetUpperBound(0); q++)
					{
						string escaped = "";
						// first get the data
						escaped = dr.ItemArray.GetValue(q).ToString();
						// now start escaping
						escaped = escaped.Replace("\"", "\"\"");
						escaped = escaped.Replace("\r", "\\r");
						escaped = escaped.Replace("\n", "\\n");

						outPut += escaped + columnDelimiter;
					}

					if ((Separator == "") || (Separator == "\",\""))
						outPut = outPut.Substring(0, outPut.Length - 2);                        // remove the last ," to have a correct line end;
					else
						outPut = outPut.Substring(0, outPut.Length - columnDelimiter.Length);    // remove the entire last content delimiter to have a correct line end;

					sw.WriteLine(outPut);
					//MessageBox.Show(outPut);
				}
				// and done
				sw.Close();        // would be done by the garbage collector, but we won't wait for it :)                
			}
		}
		#endregion
		#endregion


        #region DebugPrintDataTable
        // TODO: rewrite this to use it in conjunction with a filewriter.

		/// <summary>
		/// A simple "snippet" to DebugPrint DataTable content.
		/// 
		/// Using this function does deliver the table content delimited by ","!
		/// </summary>
		/// <param name="PrintMe">The DataTable that should be outputted</param>
		public void DebugPrintDataTable(DataTable PrintMe)
		{
			this.DebugPrintDataTable(PrintMe, "");			
		}

		/// <summary>
		/// A simple "snippet" to DebugPrint DataTable content
		/// </summary>
		/// <param name="PrintMe">The DataTable that should be outputted</param>
		/// <param name="ColumnDelimiter">The column delimiter, if any. Setting this to "" will result in "," as default delimiter!</param>
		public void DebugPrintDataTable(DataTable PrintMe, string ColumnDelimiter)
		{
			// for all the output, "," is the default column delimiter
			string columnDelimiter = "\",\"";

			if (ColumnDelimiter != "")				// well, if we need something else, here we go :)
				columnDelimiter = ColumnDelimiter;

			// tell us what you do
#if DEBUG
			Debug.Print("DebugPrintDataTable: Tablename: " + PrintMe.TableName);
			Debug.Print("");
#endif

			string outPut = "";	// helper variable

			// then, deploy the column headers first
			if (ColumnDelimiter == "")
				outPut += "\"";	// start the line with a "

			for (int x = 0 ; x < PrintMe.Columns.Count ; x++)
			{
				outPut += PrintMe.Columns[x].Caption.ToString() + columnDelimiter;
			}

			if (ColumnDelimiter == "")
				outPut = outPut.Substring(0, outPut.Length - 2);						// remove the last ," to have a correct line end;
			else
				outPut = outPut.Substring(0, outPut.Length - columnDelimiter.Length);	// remove the entire last content delimiter to have a correct line end;
#if DEBUG
			Debug.WriteLine(outPut);
#endif

			// followed by the content :)	
			outPut = "";
			if (ColumnDelimiter == "")
				outPut += "\"";	// start the line with a "

			for (int x = 0 ; x <= PrintMe.Rows.Count - 1 ; x++)
			{
				DataRow dr = PrintMe.Rows[x];
				for (int q = 0 ; q <= dr.ItemArray.GetUpperBound(0) ; q++)
				{
					outPut += dr.ItemArray.GetValue(q).ToString() + columnDelimiter;
				}

				if (ColumnDelimiter == "")
					outPut = outPut.Substring(0, outPut.Length - 2);						// remove the last ," to have a correct line end;
				else
					outPut = outPut.Substring(0, outPut.Length - columnDelimiter.Length);	// remove the entire last content delimiter to have a correct line end;
#if DEBUG
				Debug.WriteLine(outPut);
#endif
			}
			// and done
		}
		#endregion
    }
}
