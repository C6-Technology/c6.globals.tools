﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.IO;				// only needed for some stat's and encoding stuff
using System.Globalization;		// only needed for some stat's and encoding stuff
using System.Diagnostics;		// only needed for some stat's and encoding stuff
using System.Threading;			// only needed for some stat's and encoding stuff

using System.Data;

namespace SocialCom.Globals.Tools
{
	class Program
	{
		static void Main(string[] args)
		{
			/*
			 * some variables and settings
			 */
			LittleHelpers lh = new LittleHelpers();
			DataTable dt = new DataTable();

			string	Directory2Parse = @"c:\temp";
			int		NoSampleDataLines = 4;
			bool	HasHeadline = false;
			int		TimeBetweenFiles = 15;

			PerformanceCounter freeMem = new PerformanceCounter("Memory", "Available Bytes");
			/*
			 * setting default console settings, like green and black, position, buffer etc. pp. 8-)
			 */
			Console.SetWindowSize(200, 75);
			Console.SetWindowPosition(0, 0);
			Console.SetBufferSize(200, Int16.MaxValue - 1);
			ConsoleColor cc = ConsoleColor.Green;
			Console.BackgroundColor = ConsoleColor.Black;		// default, everything is green and black 8-)
			Console.Clear();			
			/*
			 * allowing some 'customization' of the settings @ runtime
			 */
			Console.Write("Path to search for CSV's in? {0}", Directory2Parse);
			Console.SetCursorPosition(Console.CursorLeft - Directory2Parse.Length, Console.CursorTop);
			Console.Beep(10000, 2000);
			string zw = Console.ReadLine();
			Directory2Parse = zw == "" ? Directory2Parse : zw;

			Console.Write("Sample DB lines to output? {0}", NoSampleDataLines);
			Console.SetCursorPosition(Console.CursorLeft - NoSampleDataLines.ToString().Length, Console.CursorTop);
			Console.Beep(10000, 2000);
			zw = Console.ReadLine();
			NoSampleDataLines = zw == "" ? NoSampleDataLines : Convert.ToInt32(int.Parse(zw));

			Console.Write("Has Headlines? {0}", HasHeadline);
			Console.SetCursorPosition(Console.CursorLeft - HasHeadline.ToString().Length, Console.CursorTop);
			Console.Beep(10000, 2000);
			zw = Console.ReadLine();
			HasHeadline = zw == "" ? HasHeadline : Convert.ToBoolean(bool.Parse(zw));

			Console.Write("Time between files in [s]? {0}", TimeBetweenFiles);
			Console.SetCursorPosition(Console.CursorLeft - TimeBetweenFiles.ToString().Length, Console.CursorTop);
			Console.Beep(10000, 2000);
			zw = Console.ReadLine();
			TimeBetweenFiles = zw == "" ? TimeBetweenFiles : Convert.ToInt32(int.Parse(zw));
			/*
			 * and now really start
			 */
			Console.Clear();
			Console.WriteLine("Starting to parse for CSV's in directory \"{0}\"", Directory2Parse);

			Console.WriteLine();
			Console.WriteLine("Settings are:");
			Console.WriteLine();
			Console.WriteLine("Searchpath            : {0}", Directory2Parse);
			Console.WriteLine("DB Samplelines        : {0}", NoSampleDataLines);
			Console.WriteLine("Has Headlines         : {0}", HasHeadline);
			Console.WriteLine("Time between files [s]: {0}", TimeBetweenFiles);
			Console.WriteLine("Seperator is          : ,");
			Console.WriteLine("File Encoding is      : UTF-8");
			Console.WriteLine();

			if (Directory.Exists(Directory2Parse))
			{
				string[] csvFiles = Directory.GetFiles(Directory2Parse, "*.csv");
				Console.WriteLine("Found {0} CSV- files within the directory, going to parse them now!", csvFiles.GetUpperBound(0));
				Console.WriteLine();

				for (int x = 0; x <= csvFiles.GetUpperBound(0); x++)
				{
					string File2Parse = csvFiles[x];
//File2Parse = @"c:\temp\defekte_csv_columns_amazon.txt";			// for debugging only :)
					
					if (File.Exists(File2Parse))
					{
						Console.WriteLine("Start handling file \"{0}\".", File2Parse);
						FileInfo fi = new FileInfo(File2Parse);
						Console.WriteLine("FileSize: {0} kb [~{1} MB]", (fi.Length / 1024).ToString("N2", CultureInfo.InvariantCulture), (fi.Length / 1024 / 1024).ToString("N1", CultureInfo.InvariantCulture));
						Console.WriteLine();

						/*
						 * count the lines in the File
						 */
						Console.WriteLine("Getting lines in file...");						
						int FileLineCounter = 0;
						Console.Write("Lines in file: {0}", FileLineCounter);
						
						using (StreamReader countReader = new StreamReader(File2Parse))
						{
							while (countReader.ReadLine() != null)
							{
								FileLineCounter++;
								Console.SetCursorPosition(0, Console.CursorTop);
								Console.Write("Lines in file: {0}", FileLineCounter);
							}
						}

						Console.WriteLine();
						Console.WriteLine();											

						DateTime StartTime = DateTime.Now;	// we take this when we really start to import :)						
						Console.WriteLine("Start time:\t{0}", StartTime.ToString());
						/*
						 * call the function itself :)
						 */
						dt = lh.CSV2DataTable(File2Parse, new string[1] { "," }, Encoding.UTF8, HasHeadline, File2Parse);
						/* 
						 * get us some sample lines
						 */
						Console.WriteLine("{0} lines of datasamples from DataTable", NoSampleDataLines);

						for (int l = 0; l < NoSampleDataLines; l++)
						{
							string DataRow = "";
							Console.WriteLine();
							Console.Write("Showing row number: ");
							Console.ForegroundColor = ConsoleColor.Red;
							Console.WriteLine(l + 1);
							Console.ForegroundColor = cc;
							Console.WriteLine();

							if (l < dt.Rows.Count)
							{
								foreach (DataColumn dc in dt.Columns)
								{
									DataRow += dt.Rows[l][dc.Caption].ToString() + " || ";
								}
								DataRow = DataRow.Substring(0, DataRow.Length - 4);	// remove the last " || "
								/*
								 * now output it, for better readability, we mark || as RED
								 */
								for (int c = 0; c < DataRow.Length; c++)
								{
									if (DataRow[c] == '|')
										Console.ForegroundColor = ConsoleColor.Red;
									else
										Console.ForegroundColor = cc;

									Console.Write(DataRow[c]);
								}
								Console.WriteLine();
							}
						}
						Console.WriteLine();
						/*
						 * and do some statistics :)
						 */
						DateTime EndTime = DateTime.Now;
						Console.WriteLine("End time:\t{0}", EndTime.ToString());
						Console.WriteLine("Time taken:\t{0}", EndTime.Subtract(StartTime).ToString());
						Console.WriteLine();
						Console.WriteLine();
						Console.WriteLine("{0} rows in file, import took in average {1} seconds per row", dt.Rows.Count, ((double)EndTime.Subtract(StartTime).Seconds / (double)dt.Rows.Count).ToString("N4", CultureInfo.InvariantCulture));
						Console.WriteLine();
						Console.WriteLine();
						/*
						 * roughly estimate the memory used by the DT 
						 */
						float FreeMemBefore = freeMem.NextValue();
						dt.Clear();
						float FreeMemAfter = freeMem.NextValue();
						Console.WriteLine("The Datatable consumes ROUGHLY estimated {0} bytes in memory", FreeMemAfter - FreeMemBefore);
						Console.WriteLine();
						Console.WriteLine("Finished handling file \"{0}\".", File2Parse);
						Console.WriteLine();						
						Console.ForegroundColor = ConsoleColor.Red;
						Console.WriteLine("Waiting for {0}s before going on with next file", TimeBetweenFiles);
						Console.ForegroundColor = cc;
						Thread.Sleep(TimeBetweenFiles * 1000);
						Console.WriteLine();
					}
					else
						Console.WriteLine("File \"{0}\" does not exist!", File2Parse);
				}
			}
			else
				Console.WriteLine("Directory \"{0}\" does not exist!", Directory2Parse);
			Console.WriteLine();
			Console.WriteLine("Please press any key...");
			Console.ReadKey();
		}
	}
}
